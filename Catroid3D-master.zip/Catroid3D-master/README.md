# Catroid3D

Experimental spike of a 3D version of Pocket Code / Catroid for Android. 

Note that this is just a very preliminary / throw-away proof of concept.

If you are interested in contributing and/or working on this 3D version, contact wolfgang.slany@catrobat.org

Licence: https://catrob.at/licenses

APK: https://github.com/Catrobat/Catroid3D/releases

Video: https://youtu.be/XgEJLIZ6YQE
